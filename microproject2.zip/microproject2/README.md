Microproject #2: MongoDB, Express, Node.js Application

Group Members:

Amritpal Singh
Harpreet Singh

Project Overview
This project is an uncomplicated execution of a Node.js application utilizing Express and MongoDB. It illustrates the "CREATE" function of CRUD operations. The app encompasses these features: 

An organized folder structure adhering to the MEN stack. 

Incorporation with MongoDB Atlas for storing databases in the cloud. 

Creating APIs with Express.js. 

Middleware for processing JSON requests. 

Dynamic database functions utilizing Mongoose. 

